
import json
import os
import sqlite3
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


def load_config(config_path="config.json"):
    """Load configuration for data sources and model name."""
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


# 1. Load data with metadata from configured movies and ratings tables
def load_data_with_metadata(config):
    movies_conf = None
    ratings_conf = None

    # Identify movie and rating sources from config
    for source in config.get("sources", []):
        role = source.get("role")
        if role == "movies":
            movies_conf = source
        elif role == "ratings":
            ratings_conf = source

    if movies_conf is None or ratings_conf is None:
        raise ValueError("Config must include sources with roles 'movies' and 'ratings'.")

    movies_db_path = movies_conf["db_path"]
    movies_table = movies_conf["table"]
    ratings_db_path = ratings_conf["db_path"]
    ratings_table = ratings_conf["table"]

    # Pull movie attributes
    with sqlite3.connect(movies_db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT movieId,imdbId,title,overview,productionCompanies,releaseDate,budget,revenue,runtime ,language, genres,status,genreDiversity, releaseEra,Audience FROM {movies_table}"
        )
        movie_rows = cursor.fetchall()

    # Aggregate ratings by movieId (average + count)
    rating_lookup = {}
    with sqlite3.connect(ratings_db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT movieId, AVG(rating) AS avg_rating, COUNT(*) AS rating_count "
            f"FROM {ratings_table} GROUP BY movieId"
        )
        for movie_id, avg_rating, rating_count in cursor.fetchall():
            rating_lookup[movie_id] = (avg_rating, rating_count)

    # Build metadata and text to embed
    metadata = []
    descriptions = []
    for (
        movie_id,
        imdb_id,
        title,
        overview,
        production_companies,
        release_date,
        budget,
        revenue,
        runtime,
        language,
        genres,
        status,
        genre_diversity,
        release_era,
        audience,
    ) in movie_rows:
        if overview is None:
            continue
        avg_rating, rating_count = rating_lookup.get(movie_id, (None, 0))
        metadata.append(
            {
                "movieId": movie_id,
                "imdbId": imdb_id,
                "title": title,
                "genre": genres,
                "description": overview,
                "productionCompanies": production_companies,
                "releaseDate": release_date,
                "budget": budget,
                "revenue": revenue,
                "runtime": runtime,
                "language": language,
                "status": status,
                "genreDiversity": genre_diversity,
                "releaseEra": release_era,
                "audience": audience,
                "avg_rating": avg_rating,
                "rating_count": rating_count,
            }
        )
        descriptions.append(overview)

    return metadata, descriptions


# 2. Normalize embeddings for cosine similarity
def normalize(vectors):
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    return vectors / norms


# 3. Build FAISS index
def build_faiss_index(embeddings):
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    return index


# 4. Search with metadata
def search_query_with_metadata(query, model, index, metadata, top_k=5):
    query_embedding = normalize(model.encode([query]))
    distances, indices = index.search(query_embedding, top_k)
    results = []
    for j, i in enumerate(indices[0]):
        results.append(
            {
                "title": metadata[i]["title"],
                "genre": metadata[i]["genre"],
                "description": metadata[i]["description"],
                "score": distances[0][j],
            }
        )
    return results


# Main pipeline
if __name__ == "__main__":
    config = load_config()
    print("Loading data from DB...")
    metadata, descriptions = load_data_with_metadata(config)
    print(f"Loaded {len(descriptions)} movies.")

    print("Generating embeddings...")
    model_name = config.get("model_name", "all-MiniLM-L6-v2")
    model = SentenceTransformer(model_name)
    embeddings = normalize(model.encode(descriptions))

    print("Building FAISS index...")
    index = build_faiss_index(embeddings)

    # Example query
    query = "Recommend a sci-fi movie with space adventure"
    print(f"\nQuery: {query}")
    results = search_query_with_metadata(query, model, index, metadata)

    print("\nTop Matches:")
    for r in results:
        print(f"- {r['title']} ({r['genre']}) -> {r['description']} [Score: {r['score']:.4f}]")