import json
import sqlite3
from typing import Dict, List, Optional, Tuple

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


def load_config(config_path: str = "config.json") -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize(vectors: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1
    return vectors / norms


class MovieRetriever:
    """
    Lightweight retrieval layer:
    - loads movies + ratings from SQLite
    - builds embeddings + FAISS index
    - exposes text search and user-based recommendation helpers
    """

    def __init__(self, config_path: str = "config.json", model_name: Optional[str] = None):
        self.config = load_config(config_path)
        self.model_name = model_name or self.config.get("model_name", "all-MiniLM-L6-v2")
        self.model = SentenceTransformer(self.model_name)

        self.movies, self.descriptions = self._load_movies()
        self.movie_id_to_idx = {m["movieId"]: i for i, m in enumerate(self.movies)}
        self.ratings_by_user = self._load_ratings()

        self.embeddings = normalize(self.model.encode(self.descriptions))
        self.index = self._build_index(self.embeddings)

    # --- data loading helpers ---
    def _load_movies(self) -> Tuple[List[dict], List[str]]:
        movies_conf = self._get_source("movies")
        db_path = movies_conf["db_path"]
        table = movies_conf["table"]

        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"""
                SELECT movieId, imdbId, title, overview, productionCompanies, releaseDate,
                       budget, revenue, runtime, language, genres, status,
                       genreDiversity, releaseEra, Audience
                FROM {table}
                """
            )
            rows = cursor.fetchall()

        movies = []
        descriptions = []
        for (
            movie_id,
            imdb_id,
            title,
            overview,
            production_companies,
            release_date,
            budget,
            revenue,
            runtime,
            language,
            genres,
            status,
            genre_diversity,
            release_era,
            audience,
        ) in rows:
            if not overview:
                continue
            movies.append(
                {
                    "movieId": movie_id,
                    "imdbId": imdb_id,
                    "title": title,
                    "description": overview,
                    "productionCompanies": production_companies,
                    "releaseDate": release_date,
                    "budget": budget,
                    "revenue": revenue,
                    "runtime": runtime,
                    "language": language,
                    "genres": genres,
                    "status": status,
                    "genreDiversity": genre_diversity,
                    "releaseEra": release_era,
                    "audience": audience,
                }
            )
            descriptions.append(overview)

        return movies, descriptions

    def _load_ratings(self) -> Dict[int, List[Tuple[int, float]]]:
        ratings_conf = self._get_source("ratings")
        db_path = ratings_conf["db_path"]
        table = ratings_conf["table"]
        ratings_by_user: Dict[int, List[Tuple[int, float]]] = {}

        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(f"SELECT userId, movieId, rating FROM {table}")
            for user_id, movie_id, rating in cursor.fetchall():
                ratings_by_user.setdefault(user_id, []).append((movie_id, rating))

        return ratings_by_user

    def _get_source(self, role: str) -> dict:
        for source in self.config.get("sources", []):
            if source.get("role") == role:
                return source
        raise ValueError(f"Config missing source with role={role}")

    # --- index helpers ---
    @staticmethod
    def _build_index(embeddings: np.ndarray) -> faiss.IndexFlatL2:
        dim = embeddings.shape[1]
        index = faiss.IndexFlatL2(dim)
        index.add(embeddings)
        return index

    # --- user profile + retrieval ---
    def user_profile_vector(self, user_id: int, min_rating: float = 4.0) -> Optional[np.ndarray]:
        rated = self.ratings_by_user.get(user_id, [])
        liked_idxs = [
            self.movie_id_to_idx[movie_id]
            for movie_id, rating in rated
            if rating is not None and rating >= min_rating and movie_id in self.movie_id_to_idx
        ]
        if not liked_idxs:
            return None
        vecs = self.embeddings[liked_idxs]
        profile = np.mean(vecs, axis=0, keepdims=True)
        return normalize(profile)

    def search_text(self, query: str, top_k: int = 5) -> List[dict]:
        query_emb = normalize(self.model.encode([query]))
        distances, indices = self.index.search(query_emb, top_k)
        results = []
        for rank, idx in enumerate(indices[0]):
            movie = self.movies[idx]
            results.append({**movie, "score": float(distances[0][rank])})
        return results

    def recommend_for_user(
        self,
        user_id: int,
        top_k: int = 5,
        min_rating: float = 4.0,
        filters: Optional[dict] = None,
    ) -> List[dict]:
        profile_vec = self.user_profile_vector(user_id, min_rating=min_rating)
        if profile_vec is None:
            return []

        distances, indices = self.index.search(profile_vec, top_k * 3)
        rated_movie_ids = {movie_id for movie_id, _ in self.ratings_by_user.get(user_id, [])}
        results = []
        for idx, score in zip(indices[0], distances[0]):
            movie = self.movies[idx]
            if movie["movieId"] in rated_movie_ids:
                continue
            if filters and not self._passes_filters(movie, filters):
                continue
            movie_with_score = {**movie, "score": float(score)}
            results.append(movie_with_score)
            if len(results) >= top_k:
                break
        return results

    def get_user_profile_stats(self, user_id: int, min_rating: float = 4.0) -> dict:
        rated = self.ratings_by_user.get(user_id, [])
        likes = [m for m in rated if m[1] >= min_rating]
        if not likes:
            return {"liked_count": 0, "top_genres": [], "avg_rating": None}

        genres: Dict[str, int] = {}
        total = 0
        for movie_id, rating in likes:
            movie = self._movie_by_id(movie_id)
            if not movie:
                continue
            total += rating
            for g in (movie.get("genres") or "").split("|"):
                if not g:
                    continue
                genres[g] = genres.get(g, 0) + 1

        top_genres = sorted(genres.items(), key=lambda x: x[1], reverse=True)[:5]
        return {
            "liked_count": len(likes),
            "top_genres": [g for g, _ in top_genres],
            "avg_rating": total / len(likes),
        }

    def fetch_movies(self, movie_ids: List[int]) -> List[dict]:
        return [m for m in self.movies if m["movieId"] in set(movie_ids)]

    # --- utilities ---
    def _passes_filters(self, movie: dict, filters: dict) -> bool:
        if filters.get("genres"):
            movie_genres = set((movie.get("genres") or "").split("|"))
            if not movie_genres.intersection(set(filters["genres"])):
                return False
        if filters.get("language") and movie.get("language") != filters["language"]:
            return False
        if filters.get("max_runtime") and movie.get("runtime") and movie["runtime"] > filters["max_runtime"]:
            return False
        if filters.get("min_revenue") and movie.get("revenue") and movie["revenue"] < filters["min_revenue"]:
            return False
        if filters.get("min_budget") and movie.get("budget") and movie["budget"] < filters["min_budget"]:
            return False
        return True

    def _movie_by_id(self, movie_id: int) -> Optional[dict]:
        idx = self.movie_id_to_idx.get(movie_id)
        if idx is None:
            return None
        return self.movies[idx]


if __name__ == "__main__":
    # Quick sanity check without LLM calls
    retriever = MovieRetriever()
    print("Top 3 text matches for 'space adventure':")
    for m in retriever.search_text("space adventure", top_k=3):
        print(f"- {m['title']} :: {m['genres']} (score={m['score']:.4f})")

    example_user = next(iter(retriever.ratings_by_user.keys()), None)
    if example_user:
        recs = retriever.recommend_for_user(example_user, top_k=3)
        print(f"\nRecommendations for user {example_user}:")
        for r in recs:
            print(f"- {r['title']} :: {r['genres']} (score={r['score']:.4f})")

