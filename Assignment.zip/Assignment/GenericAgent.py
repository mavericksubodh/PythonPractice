import os
from google import genai
from google.genai import types
from openai import OpenAI

class GenericAgent:
    def __init__(
            self,
            provider="gemini",               # default gemini
            project_id=None,
            location="global",
            gemini_model="gemini-2.5-flash",
            openai_model="gpt-4o-mini",
            openai_api_key=None,
    ):
        self.provider = provider.lower()
        if self.provider == "gemini":
            project_id = project_id or os.getenv("GOOGLE_CLOUD_PROJECT")
            self.client = genai.Client(vertexai=True, project=project_id, location=location)
            self.model_name = gemini_model
        elif self.provider == "openai":
            openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
            self.client = OpenAI(api_key=openai_api_key or os.getenv("OPEN_API_KEY"))
            self.model_name = openai_model
        else:
            raise ValueError("provider must be 'gemini' or 'openai'.")

    def generate_content(self, prompt):
        if self.provider == "gemini":
            contents = [types.Content(role="user", parts=[types.Part(text=prompt)])]
            config = types.GenerateContentConfig(
                temperature=1,
                top_p=0.95,
                max_output_tokens=1200,
            )
            resp = self.client.models.generate_content(
                model=self.model_name, contents=contents, config=config
            )
            print(resp.text)
            return resp.text
        else:  # openai
            resp = self.client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}]
            )
            text = resp.choices[0].message.content
            print(text)
            return text