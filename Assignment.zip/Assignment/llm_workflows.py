import os
from typing import List, Optional

from GenericAgent import GenericAgent
from data_pipeline import MovieRetriever


def _format_movie_brief(movie: dict) -> str:
    parts = [
        f"title: {movie.get('title')}",
        f"genres: {movie.get('genres')}",
        f"runtime: {movie.get('runtime')}",
        f"budget: {movie.get('budget')}",
        f"revenue: {movie.get('revenue')}",
        f"releaseDate: {movie.get('releaseDate')}",
    ]
    return "; ".join(parts)


def recommend_with_llm(
    agent: GenericAgent,
    retriever: MovieRetriever,
    user_id: int,
    top_k: int = 5,
    filters: Optional[dict] = None,
) -> str:
    profile_stats = retriever.get_user_profile_stats(user_id)
    recs = retriever.recommend_for_user(user_id, top_k=top_k, filters=filters)

    if not recs:
        return f"No recommendations available for user {user_id}. Try relaxing filters."

    movie_context = "\n".join([_format_movie_brief(m) for m in recs])
    prompt = f"""
You are a helpful movie assistant. Use only the provided movie context to respond.

User profile:
- userId: {user_id}
- liked_count: {profile_stats.get('liked_count')}
- top_genres: {profile_stats.get('top_genres')}
- avg_rating: {profile_stats.get('avg_rating')}
- filters: {filters}

Candidate movies:
{movie_context}

Task: Provide {top_k} personalized recommendations. For each, include title, why it fits (cite genre/runtime/budget or revenue relevance), and keep it to one concise sentence per movie.
"""
    return agent.generate_content(prompt)


def summarize_user_with_llm(agent: GenericAgent, retriever: MovieRetriever, user_id: int) -> str:
    profile_stats = retriever.get_user_profile_stats(user_id)
    if profile_stats.get("liked_count", 0) == 0:
        return f"No strong preferences found for user {user_id}."

    prompt = f"""
You are a movie analyst. Summarize the user's taste based on the stats below and suggest 3 short next-watch ideas.

User profile:
- userId: {user_id}
- liked_count: {profile_stats.get('liked_count')}
- top_genres: {profile_stats.get('top_genres')}
- avg_rating: {profile_stats.get('avg_rating')}

Output: 2-3 bullet summary of preferences + 3 suggested directions (no specific titles needed).
"""
    return agent.generate_content(prompt)


def compare_movies_with_llm(agent: GenericAgent, retriever: MovieRetriever, movie_ids: List[int]) -> str:
    movies = retriever.fetch_movies(movie_ids)
    if len(movies) < 2:
        return "Need at least two movies to compare."

    movie_context = "\n".join([_format_movie_brief(m) for m in movies])
    prompt = f"""
You are comparing movies. Use only the given data.

Movies:
{movie_context}

Task: Produce a concise comparison covering budget, revenue, runtime, and notable genre differences. Conclude with 1-2 sentences on which fits big-budget vs quick-watch preferences.
"""
    return agent.generate_content(prompt)


if __name__ == "__main__":
    # Example wiring for quick manual runs (requires env vars for provider choice)
    provider = os.getenv("PROVIDER", "gemini")
    agent = GenericAgent(provider=provider)
    retriever = MovieRetriever()

    # Pick a sample user (first available)
    example_user = next(iter(retriever.ratings_by_user.keys()), None)
    if example_user:
        print("=== Recommendations ===")
        print(recommend_with_llm(agent, retriever, example_user, top_k=3))

        print("\n=== User Summary ===")
        print(summarize_user_with_llm(agent, retriever, example_user))

    # Example comparison of first two movies
    sample_movie_ids = [m["movieId"] for m in retriever.movies[:2]]
    print("\n=== Comparison ===")
    print(compare_movies_with_llm(agent, retriever, sample_movie_ids))

